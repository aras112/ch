package com.comarch.comarch.entities;

import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
@Data
@NoArgsConstructor


public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(nullable = false)
    @Size(min = 4, max = 20)
    @NotNull(message = "name is null")
    private String name;

    @Size(min = 4, max = 20)
    @NotNull(message = "name is null")
    private String surname;

    @Min(18)
    @Max(150)
    private Integer age;
}
