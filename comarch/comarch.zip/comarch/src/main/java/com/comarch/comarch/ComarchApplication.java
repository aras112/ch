package com.comarch.comarch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ComarchApplication {

	public static void main(String[] args) {
		SpringApplication.run(ComarchApplication.class, args);
	}

}
