package com.comarch.comarch.entities;

public enum Currency {
    PLN,EUR
}
